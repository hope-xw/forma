import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";

const nodes: RuntimeNode[] = [
  {
    "id": "Feedback",
    "name": "Feedback",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": "100%",
      "height": 400,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "grid",
      "gap": 12,
      "flexShrink": 0,
      "justifyContent": "start",
      "alignItems": "start",
      "gridTemplateColumns": "repeat(var(--forma-grid-46-65-65-64-62-61-63-6b, 3),minmax(0,1fr))",
      "gridAutoRows": "48px",
      "alignContent": "start",
      "columnGap": "var(--forma-grid-46-65-65-64-62-61-63-6b-gap, 12px)",
      "rowGap": "var(--forma-grid-46-65-65-64-62-61-63-6b-gap, 12px)",
      "justifyItems": "start",
      "background": "#21252c",
      "color": "#ffffff",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "--aura-bg-canvas": "#0b0d14",
      "--aura-bg-surface": "#131724",
      "--aura-bg-subtle": "#1a2033",
      "--aura-border-subtle": "#262e45",
      "--aura-text-primary": "#f5f7ff",
      "--aura-text-secondary": "#96a0bc",
      "--aura-brand-primary": "#7c5cff",
      "--aura-brand-soft": "#221b47",
      "--aura-status-green": "#22c55e",
      "--aura-status-cyan": "#38bdf8",
      "margin": 0
    },
    "geometry": {
      "width": 768,
      "height": 400
    },
    "gridBreakpoint": {
      "maxWidth": 600,
      "columns": 1,
      "gap": 8,
      "variable": "--forma-grid-46-65-65-64-62-61-63-6b"
    },
    "children": [
      {
        "id": "Card",
        "name": "Card",
        "text": "",
        "type": "rectangle",
        "style": {
          "boxSizing": "border-box",
          "width": "auto",
          "height": "auto",
          "position": "relative",
          "display": "block",
          "flexShrink": 0,
          "gridColumn": "span min(3, var(--forma-grid-46-65-65-64-62-61-63-6b, 3))",
          "gridRow": "span 2",
          "minWidth": 1,
          "justifySelf": "stretch",
          "minHeight": 1,
          "alignSelf": "stretch",
          "background": "linear-gradient(135deg, color-mix(in srgb, var(--aura-bg-surface) 100%, transparent) 0%, rgba(147, 131, 255, 1) 100%)",
          "color": "#ffffff",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "Name",
        "name": "Name",
        "text": "",
        "type": "rectangle",
        "style": {
          "boxSizing": "border-box",
          "width": "auto",
          "height": 40,
          "position": "relative",
          "display": "block",
          "flexShrink": 0,
          "minWidth": 1,
          "justifySelf": "stretch",
          "background": "#21252c",
          "color": "#ffffff",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "geometry": {
          "width": 248,
          "height": 40
        },
        "control": {
          "kind": "textfield",
          "label": "联系邮箱",
          "value": ""
        },
        "children": []
      },
      {
        "id": "Submit",
        "name": "Submit",
        "text": "发送",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": "auto",
          "height": 40,
          "position": "relative",
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "minWidth": 1,
          "justifySelf": "stretch",
          "background": "#21252c",
          "color": "#ffffff",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "geometry": {
          "width": 248,
          "height": 40
        },
        "control": {
          "kind": "button",
          "label": "提交表单",
          "value": false
        },
        "children": []
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":0,"minHeight":800,"fontFamily":"system-ui, sans-serif","width":"100%"} as CSSProperties;

export default function DesignPage({ flow, onAction }: { flow?: string; onAction?: DesignAction }) {
  const screen = nodes.find(n => n.id === flow) ?? nodes[0];
  return <main style={{...pageStyle, minWidth: 0, minHeight: 0}}>{screen && <DesignNodeView node={{...screen, style:{...screen.style, position:'relative', left:0, top:0}}} onAction={onAction}/>}</main>;
}

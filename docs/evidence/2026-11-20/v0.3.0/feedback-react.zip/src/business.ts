import type { DesignAction } from './FormaRuntime';
export const onDesignAction:DesignAction=(id,value)=>{document.body.dataset.lastFormEvent=id+'='+String(value);};

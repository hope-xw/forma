import type { DesignAction } from "./FormaRuntime";
import { FileRouter } from "./FileRouter";
import { pages, start } from "./pages";
export default function DesignPage({ onAction }: {onAction?: DesignAction}) { return <FileRouter pages={pages} start={start} onAction={onAction}/>; }

// Resolved default-mode values plus stable CSS names. Full collections, aliases and styles are in design-system.json.
export const tokens = {
  "palette-light-canvas": {
    "name": "Color/Light/canvas",
    "type": "color",
    "value": "#f3f5f9",
    "cssName": "--palette-light-canvas"
  },
  "palette-light-surface": {
    "name": "Color/Light/surface",
    "type": "color",
    "value": "#ffffff",
    "cssName": "--palette-light-surface"
  },
  "palette-light-secondary": {
    "name": "Color/Light/secondary",
    "type": "color",
    "value": "#e9edf4",
    "cssName": "--palette-light-secondary"
  },
  "palette-light-text": {
    "name": "Color/Light/text",
    "type": "color",
    "value": "#192234",
    "cssName": "--palette-light-text"
  },
  "palette-light-muted": {
    "name": "Color/Light/muted",
    "type": "color",
    "value": "#778195",
    "cssName": "--palette-light-muted"
  },
  "palette-light-border": {
    "name": "Color/Light/border",
    "type": "color",
    "value": "#dce2ec",
    "cssName": "--palette-light-border"
  },
  "palette-light-accent": {
    "name": "Color/Light/accent",
    "type": "color",
    "value": "#246bfd",
    "cssName": "--palette-light-accent"
  },
  "palette-light-tint": {
    "name": "Color/Light/tint",
    "type": "color",
    "value": "#e6eeff",
    "cssName": "--palette-light-tint"
  },
  "palette-light-danger": {
    "name": "Color/Light/danger",
    "type": "color",
    "value": "#df354d",
    "cssName": "--palette-light-danger"
  },
  "palette-light-success": {
    "name": "Color/Light/success",
    "type": "color",
    "value": "#25a975",
    "cssName": "--palette-light-success"
  },
  "palette-dark-canvas": {
    "name": "Color/Dark/canvas",
    "type": "color",
    "value": "#11151d",
    "cssName": "--palette-dark-canvas"
  },
  "palette-dark-surface": {
    "name": "Color/Dark/surface",
    "type": "color",
    "value": "#202734",
    "cssName": "--palette-dark-surface"
  },
  "palette-dark-secondary": {
    "name": "Color/Dark/secondary",
    "type": "color",
    "value": "#303a4c",
    "cssName": "--palette-dark-secondary"
  },
  "palette-dark-text": {
    "name": "Color/Dark/text",
    "type": "color",
    "value": "#f5f7fc",
    "cssName": "--palette-dark-text"
  },
  "palette-dark-muted": {
    "name": "Color/Dark/muted",
    "type": "color",
    "value": "#a0acc0",
    "cssName": "--palette-dark-muted"
  },
  "palette-dark-border": {
    "name": "Color/Dark/border",
    "type": "color",
    "value": "#394459",
    "cssName": "--palette-dark-border"
  },
  "palette-dark-accent": {
    "name": "Color/Dark/accent",
    "type": "color",
    "value": "#77a3ff",
    "cssName": "--palette-dark-accent"
  },
  "palette-dark-tint": {
    "name": "Color/Dark/tint",
    "type": "color",
    "value": "#253d66",
    "cssName": "--palette-dark-tint"
  },
  "palette-dark-danger": {
    "name": "Color/Dark/danger",
    "type": "color",
    "value": "#ff7588",
    "cssName": "--palette-dark-danger"
  },
  "palette-dark-success": {
    "name": "Color/Dark/success",
    "type": "color",
    "value": "#52d6a2",
    "cssName": "--palette-dark-success"
  },
  "color-canvas": {
    "name": "Color/canvas",
    "type": "color",
    "value": "#f3f5f9",
    "cssName": "--color-canvas"
  },
  "color-surface": {
    "name": "Color/surface",
    "type": "color",
    "value": "#ffffff",
    "cssName": "--color-surface"
  },
  "color-secondary": {
    "name": "Color/secondary",
    "type": "color",
    "value": "#e9edf4",
    "cssName": "--color-secondary"
  },
  "color-text": {
    "name": "Color/text",
    "type": "color",
    "value": "#192234",
    "cssName": "--color-text"
  },
  "color-muted": {
    "name": "Color/muted",
    "type": "color",
    "value": "#778195",
    "cssName": "--color-muted"
  },
  "color-border": {
    "name": "Color/border",
    "type": "color",
    "value": "#dce2ec",
    "cssName": "--color-border"
  },
  "color-accent": {
    "name": "Color/accent",
    "type": "color",
    "value": "#246bfd",
    "cssName": "--color-accent"
  },
  "color-tint": {
    "name": "Color/tint",
    "type": "color",
    "value": "#e6eeff",
    "cssName": "--color-tint"
  },
  "color-danger": {
    "name": "Color/danger",
    "type": "color",
    "value": "#df354d",
    "cssName": "--color-danger"
  },
  "color-success": {
    "name": "Color/success",
    "type": "color",
    "value": "#25a975",
    "cssName": "--color-success"
  },
  "space-sm": {
    "name": "Spacing/space-sm",
    "type": "number",
    "value": 8,
    "cssName": "--space-sm"
  },
  "space-md": {
    "name": "Spacing/space-md",
    "type": "number",
    "value": 16,
    "cssName": "--space-md"
  },
  "space-lg": {
    "name": "Spacing/space-lg",
    "type": "number",
    "value": 24,
    "cssName": "--space-lg"
  },
  "radius-sm": {
    "name": "Radius/radius-sm",
    "type": "number",
    "value": 8,
    "cssName": "--radius-sm"
  },
  "radius-md": {
    "name": "Radius/radius-md",
    "type": "number",
    "value": 16,
    "cssName": "--radius-md"
  },
  "text-body": {
    "name": "Typography/text-body",
    "type": "number",
    "value": 16,
    "cssName": "--text-body"
  },
  "text-title": {
    "name": "Typography/text-title",
    "type": "number",
    "value": 28,
    "cssName": "--text-title"
  },
  "font-family": {
    "name": "Typography/Family",
    "type": "string",
    "value": "system-ui, sans-serif",
    "cssName": "--font-family"
  },
  "content-label": {
    "name": "Content/Primary action",
    "type": "string",
    "value": "继续",
    "cssName": "--forma-63-6f-6e-74-65-6e-74-2d-6c-61-62-65-6c"
  },
  "content-visible": {
    "name": "Visibility/Content",
    "type": "boolean",
    "value": true,
    "cssName": "--forma-63-6f-6e-74-65-6e-74-2d-76-69-73-69-62-6c-65"
  },
  "mobile-color-canvas": {
    "name": "Mobile/canvas",
    "type": "color",
    "value": "#f3f5f9",
    "cssName": "--mobile-color-canvas"
  },
  "mobile-color-surface": {
    "name": "Mobile/surface",
    "type": "color",
    "value": "#ffffff",
    "cssName": "--mobile-color-surface"
  },
  "mobile-color-secondary": {
    "name": "Mobile/secondary",
    "type": "color",
    "value": "#e9edf4",
    "cssName": "--mobile-color-secondary"
  },
  "mobile-color-text": {
    "name": "Mobile/text",
    "type": "color",
    "value": "#192234",
    "cssName": "--mobile-color-text"
  },
  "mobile-color-muted": {
    "name": "Mobile/muted",
    "type": "color",
    "value": "#778195",
    "cssName": "--mobile-color-muted"
  },
  "mobile-color-border": {
    "name": "Mobile/border",
    "type": "color",
    "value": "#dce2ec",
    "cssName": "--mobile-color-border"
  },
  "mobile-color-accent": {
    "name": "Mobile/accent",
    "type": "color",
    "value": "#246bfd",
    "cssName": "--mobile-color-accent"
  },
  "mobile-color-tint": {
    "name": "Mobile/tint",
    "type": "color",
    "value": "#e6eeff",
    "cssName": "--mobile-color-tint"
  },
  "mobile-color-danger": {
    "name": "Mobile/danger",
    "type": "color",
    "value": "#df354d",
    "cssName": "--mobile-color-danger"
  },
  "mobile-color-success": {
    "name": "Mobile/success",
    "type": "color",
    "value": "#25a975",
    "cssName": "--mobile-color-success"
  },
  "atlas-ink": {
    "name": "Atlas/ink",
    "type": "color",
    "value": "#172f2b",
    "cssName": "--atlas-ink"
  },
  "atlas-muted": {
    "name": "Atlas/muted",
    "type": "color",
    "value": "#5d7069",
    "cssName": "--atlas-muted"
  },
  "atlas-paper": {
    "name": "Atlas/paper",
    "type": "color",
    "value": "#fbfaf4",
    "cssName": "--atlas-paper"
  },
  "atlas-forest": {
    "name": "Atlas/forest",
    "type": "color",
    "value": "#1c594a",
    "cssName": "--atlas-forest"
  },
  "atlas-orange": {
    "name": "Atlas/orange",
    "type": "color",
    "value": "#bb552c",
    "cssName": "--atlas-orange"
  }
} as const;

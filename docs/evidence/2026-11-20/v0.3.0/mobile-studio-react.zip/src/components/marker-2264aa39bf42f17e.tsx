import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "路线站点";
export type Variant = "point0" | "point1" | "point2";
const variants: Record<Variant, RuntimeNode> = {
  "point0": {
    "id": "root",
    "name": "雾岭南口",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 32,
      "height": 32,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "color-mix(in srgb, var(--atlas-forest) 100%, transparent)",
      "color": "#192234",
      "borderRadius": 16,
      "fontSize": 17,
      "padding": 0,
      "border": "2px solid #ffffff",
      "fontFamily": "system-ui, sans-serif",
      "lineHeight": "24px",
      "overflow": "hidden",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 32,
      "height": 32
    },
    "children": [
      {
        "id": "label",
        "name": "1",
        "key": "label",
        "text": "1",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 28,
          "height": 20,
          "position": "absolute",
          "left": -2,
          "top": 3,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "color-mix(in srgb, var(--atlas-paper) 100%, transparent)",
          "borderRadius": 0,
          "fontSize": 15,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 750,
          "lineHeight": "20px",
          "textAlign": "center",
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  "point1": {
    "id": "root",
    "name": "澄溪营地",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 32,
      "height": 32,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "color-mix(in srgb, var(--atlas-orange) 100%, transparent)",
      "color": "#192234",
      "borderRadius": 16,
      "fontSize": 17,
      "padding": 0,
      "border": "2px solid #ffffff",
      "fontFamily": "system-ui, sans-serif",
      "lineHeight": "24px",
      "overflow": "hidden",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 32,
      "height": 32
    },
    "children": [
      {
        "id": "label",
        "name": "2",
        "key": "label",
        "text": "2",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 28,
          "height": 20,
          "position": "absolute",
          "left": -2,
          "top": 3,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "color-mix(in srgb, var(--atlas-paper) 100%, transparent)",
          "borderRadius": 0,
          "fontSize": 15,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 750,
          "lineHeight": "20px",
          "textAlign": "center",
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  "point2": {
    "id": "root",
    "name": "北峰观景台",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 32,
      "height": 32,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "color-mix(in srgb, var(--atlas-ink) 100%, transparent)",
      "color": "#192234",
      "borderRadius": 16,
      "fontSize": 17,
      "padding": 0,
      "border": "2px solid #ffffff",
      "fontFamily": "system-ui, sans-serif",
      "lineHeight": "24px",
      "overflow": "hidden",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 32,
      "height": 32
    },
    "children": [
      {
        "id": "label",
        "name": "3",
        "key": "label",
        "text": "3",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 28,
          "height": 20,
          "position": "absolute",
          "left": -2,
          "top": 3,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "color-mix(in srgb, var(--atlas-paper) 100%, transparent)",
          "borderRadius": 0,
          "fontSize": 15,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 750,
          "lineHeight": "20px",
          "textAlign": "center",
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
};
type Props = { node: RuntimeNode; onAction?: DesignAction } | { instanceId: string; variant?: Variant; text?: Record<string, string>; onAction?: DesignAction };
export default function DesignComponent(props: Props) {
  const node = "node" in props ? props.node : instanceTemplate(variants[props.variant ?? "point0"], props.instanceId, props.text);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

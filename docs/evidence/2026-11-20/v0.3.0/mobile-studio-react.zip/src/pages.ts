import type { ExportedPage } from "./FileRouter";
export const pages: ExportedPage[] = [
  { id: "ipad", name: "01  iPad · 工作空间", screens: [{"id":"2af89d1d-c8f4-44d3-81e4-76cfd259bd44","name":"分栏导航 · Light"},{"id":"e863a26f-7063-424d-8ca5-a2de05846262","name":"协作分享 · Light"},{"id":"5e8b5438-0587-463c-a0d6-cd0599bacde8","name":"文件浏览与长按 · Light"},{"id":"3043708f-e647-48a1-b52d-0bd7daf226ab","name":"协作分享 · Dark"},{"id":"fb60e9db-72ea-4d32-8215-4f8a7269b9bd","name":"上下文菜单 · Light"},{"id":"sheet-c03ed0aa-dbee-40a5-8e55-1fd61bc77854","name":"共享 · 浮层"}], load: () => import("./Page1") },
  { id: "iphone", name: "02  iPhone · 发现与设置", screens: [{"id":"17b1d254-3d68-4f41-8bff-8752401574f7","name":"手机 · 设置 · Light"},{"id":"e3d36fb4-dda1-4ead-b985-f21f0521b013","name":"手机 · 设置 · Light / 操作菜单"},{"id":"656bd4d2-13d7-4a00-bab0-81c16c5f8acb","name":"手机 · 内容发现 · Dark"},{"id":"95a3e457-95f8-4b1f-ae35-1447db6c4215","name":"手机 · 内容发现 · Dark / 分享面板"}], load: () => import("./Page2") },
  { id: "sound", name: "03  Soundspace · 音乐", screens: [{"id":"77f272c8-b198-4143-922d-44014c89e546","name":"平板 · 声场音乐工作台"},{"id":"6d8bd64c-b80b-41a2-9663-f9cd6414fc68","name":"平板 · 声场音乐工作台"}], load: () => import("./Page3") },
  { id: "atlas", name: "04  Field Atlas · 野径图志", screens: [{"id":"atlas-tablet-root","name":"iPad · 雾岭路线规划"},{"id":"atlas-phone-root","name":"iPhone · 雾岭环线"},{"id":"atlas-note-root","name":"iPhone · 路线手记"},{"id":"atlas-sheet-root","name":"路线分享 · 浮层"}], load: () => import("./Page4") }
];
export const start = "atlas-tablet-root";

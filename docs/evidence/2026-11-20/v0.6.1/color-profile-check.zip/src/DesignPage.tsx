import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { ImageResources } from "./FormaRuntime";
import images from "./design-images";

const nodes: RuntimeNode[] = [
  {
    "id": "7821c388-cf9f-4a8c-bed2-fbe488d04581",
    "name": "01 / 工作空间",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 760,
      "height": 540,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "flex",
      "flexDirection": "column",
      "gap": 20,
      "flexShrink": 0,
      "justifyContent": "start",
      "alignItems": "start",
      "background": "color(display-p3 0.9176471 0.2 0.1372549)",
      "color": "color(display-p3 0.1254902 0.1607843 0.227451)",
      "borderRadius": 8,
      "fontSize": 16,
      "padding": 40,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 760,
      "height": 540
    },
    "children": [
      {
        "id": "5cfa3e3c-80ee-43e7-9fb3-69555de37a9f",
        "name": "标题",
        "text": "让好设计，发生。",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 680,
          "height": 64,
          "position": "relative",
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "color(display-p3 0.1254902 0.1607843 0.227451)",
          "borderRadius": 0,
          "fontSize": 36,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "4c5c40cb-1392-420f-aa69-043e4b77b342",
        "name": "描述",
        "text": "从一个想法开始，和团队一起创造下一个作品。",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 680,
          "height": 60,
          "position": "relative",
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "color(display-p3 0.4039216 0.454902 0.5372549)",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "9e35861b-33bd-4d58-a351-19188207f956",
        "name": "内容卡片",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 680,
          "height": 140,
          "position": "relative",
          "display": "flex",
          "flexDirection": "column",
          "gap": 12,
          "flexShrink": 0,
          "justifyContent": "start",
          "alignItems": "start",
          "background": "color(display-p3 0.9490196 0.9411765 0.9960784)",
          "color": "color(display-p3 0.1254902 0.1607843 0.227451)",
          "borderRadius": 16,
          "fontSize": 16,
          "padding": 24,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "image": {
          "assetId": "img-75b1c93efff464961374c0b5c51bc45667141d006b7e77abc5f0a2ec751a0723",
          "fit": "cover",
          "x": 50,
          "y": 50,
          "zoom": 1
        },
        "children": [
          {
            "id": "d92b9323-0005-4643-97f4-ce11af31fc11",
            "name": "文本",
            "text": "你的下一个灵感",
            "type": "text",
            "style": {
              "boxSizing": "border-box",
              "width": 632,
              "height": 40,
              "position": "relative",
              "display": "block",
              "flexShrink": 0,
              "background": "transparent",
              "color": "color(display-p3 0.1254902 0.1607843 0.227451)",
              "borderRadius": 0,
              "fontSize": 20,
              "padding": 0,
              "border": 0,
              "fontFamily": "system-ui, sans-serif",
              "fontWeight": 400,
              "lineHeight": 1.4,
              "letterSpacing": 0,
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      },
      {
        "id": "5bd52669-2390-48ee-8e54-256632710a7b",
        "name": "开始创作",
        "text": "创建新项目",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 160,
          "height": 44,
          "position": "relative",
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "var(--token-brand)",
          "color": "color(display-p3 1 1 1)",
          "borderRadius": 8,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
];
const pageStyle = {"--token-brand":"color(display-p3 0.3882353 0.3568627 1)","position":"relative","minWidth":760,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ onAction }: { onAction?: DesignAction }) {
  return <ImageResources.Provider value={images}><main style={pageStyle}>{nodes.map(node => <DesignNodeView key={node.id} node={node} onAction={onAction}/>)}</main></ImageResources.Provider>;
}

export default {
  "img-75b1c93efff464961374c0b5c51bc45667141d006b7e77abc5f0a2ec751a0723": { data: new URL("./assets/img-75b1c93efff464961374c0b5c51bc45667141d006b7e77abc5f0a2ec751a0723.png", import.meta.url).href },
};

import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "Secondary";
export type Variant = "default";
const variants: Record<Variant, RuntimeNode> = {
  "default": {
    "id": "Secondary",
    "name": "Secondary",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 90,
      "height": 32,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#16222a",
      "borderRadius": 0,
      "fontSize": 14,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 90,
      "height": 32
    },
    "children": [
      {
        "id": "AlternateMark",
        "name": "AlternateMark",
        "key": "root/AlternateMark:0",
        "text": "新版标识",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 90,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#16222a",
          "borderRadius": 0,
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "Dot",
        "name": "Dot",
        "key": "root/Dot:0",
        "text": "",
        "type": "ellipse",
        "style": {
          "boxSizing": "border-box",
          "width": 8,
          "height": 8,
          "position": "absolute",
          "left": 72,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#16222a",
          "borderRadius": "50%",
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
};
export type ComponentValues = {};
const fields: {name: keyof ComponentValues; kind: string; target: string}[] = [];
type Choice = { variant?: Variant };
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const value = props.values[field.name];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[props.variant ?? "default"], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

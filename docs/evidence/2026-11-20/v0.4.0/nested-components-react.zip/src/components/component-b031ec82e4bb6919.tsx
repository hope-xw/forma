import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "Toolbar";
export type Variant = "default";
const variants: Record<Variant, RuntimeNode> = {
  "default": {
    "id": "Toolbar",
    "name": "Toolbar",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 200,
      "height": 75,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#16222a",
      "borderRadius": 0,
      "fontSize": 14,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 200,
      "height": 75
    },
    "children": [
      {
        "id": "Heading",
        "name": "Heading",
        "key": "root/Heading:0",
        "text": "操作",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 90,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#16222a",
          "borderRadius": 0,
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "d3a05ecf-4669-4d23-b785-3c559cdb965b",
        "name": "Primary",
        "key": "root/Primary:0",
        "component": "[\"49864da8-0ec4-4d86-bd6c-e7dd3877660d\",\"component\"]",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 90,
          "height": 32,
          "position": "absolute",
          "left": 24,
          "top": 24,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#16222a",
          "borderRadius": 0,
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "ca7567f8-1cf9-4d1d-b4a9-462b364cbdd7",
            "name": "DefaultMark",
            "key": "root/Primary:0/DefaultMark:0",
            "text": "普通标识",
            "type": "text",
            "style": {
              "boxSizing": "border-box",
              "width": 90,
              "height": 32,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "transparent",
              "color": "#16222a",
              "borderRadius": 0,
              "fontSize": 14,
              "padding": 0,
              "border": 0,
              "fontFamily": "system-ui, sans-serif",
              "fontWeight": 400,
              "lineHeight": 1.4,
              "letterSpacing": 0,
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      }
    ]
  }
};
export type ComponentValues = {"标题"?: string; "标识"?: import("react").ReactNode};
const fields: {name: keyof ComponentValues; kind: string; target: string}[] = [{"name":"标题","kind":"text","target":"root/Heading:0"},{"name":"标识","kind":"swap","target":"root/Primary:0"}];
type Choice = { variant?: Variant };
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const value = props.values[field.name];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[props.variant ?? "default"], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "Header";
export type Variant = "default";
const variants: Record<Variant, RuntimeNode> = {
  "default": {
    "id": "Header",
    "name": "Header",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 260,
      "height": 110,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#16222a",
      "borderRadius": 0,
      "fontSize": 14,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 260,
      "height": 110
    },
    "children": [
      {
        "id": "de8c5eb8-489a-41d7-a1ae-3cdf539b1678",
        "name": "Toolbar",
        "key": "root/Toolbar:0",
        "component": "[\"2a5d8f77-f657-44e6-9c39-fe9e23b68bf0\",\"component\"]",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 200,
          "height": 75,
          "position": "absolute",
          "left": 24,
          "top": 24,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#16222a",
          "borderRadius": 0,
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "e77afb70-fa57-42f0-926a-9d18c7f4321d",
            "name": "Heading",
            "key": "root/Toolbar:0/Heading:0",
            "text": "操作",
            "type": "text",
            "style": {
              "boxSizing": "border-box",
              "width": 90,
              "height": 32,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "transparent",
              "color": "#16222a",
              "borderRadius": 0,
              "fontSize": 14,
              "padding": 0,
              "border": 0,
              "fontFamily": "system-ui, sans-serif",
              "fontWeight": 400,
              "lineHeight": 1.4,
              "letterSpacing": 0,
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          },
          {
            "id": "9a6fabf6-bdd4-4b35-b39a-5ee208a8e1d1",
            "name": "Primary",
            "key": "root/Toolbar:0/Primary:0",
            "component": "[\"49864da8-0ec4-4d86-bd6c-e7dd3877660d\",\"component\"]",
            "text": "",
            "type": "frame",
            "style": {
              "boxSizing": "border-box",
              "width": 90,
              "height": 32,
              "position": "absolute",
              "left": 24,
              "top": 24,
              "display": "block",
              "flexShrink": 0,
              "background": "#ffffff",
              "color": "#16222a",
              "borderRadius": 0,
              "fontSize": 14,
              "padding": 0,
              "border": 0,
              "fontFamily": "inherit",
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": [
              {
                "id": "bae8e32b-6c07-43e4-bec2-a157c14c78f0",
                "name": "DefaultMark",
                "key": "root/Toolbar:0/Primary:0/DefaultMark:0",
                "text": "普通标识",
                "type": "text",
                "style": {
                  "boxSizing": "border-box",
                  "width": 90,
                  "height": 32,
                  "position": "absolute",
                  "left": 0,
                  "top": 0,
                  "display": "block",
                  "flexShrink": 0,
                  "background": "transparent",
                  "color": "#16222a",
                  "borderRadius": 0,
                  "fontSize": 14,
                  "padding": 0,
                  "border": 0,
                  "fontFamily": "system-ui, sans-serif",
                  "fontWeight": 400,
                  "lineHeight": 1.4,
                  "letterSpacing": 0,
                  "whiteSpace": "pre-wrap",
                  "overflowWrap": "break-word",
                  "margin": 0
                },
                "children": []
              }
            ]
          }
        ]
      }
    ]
  }
};
export type ComponentValues = {"页头标题"?: string; "页头标识"?: import("react").ReactNode};
const fields: {name: keyof ComponentValues; kind: string; target: string}[] = [{"name":"页头标题","kind":"text","target":"root/Toolbar:0/Heading:0"},{"name":"页头标识","kind":"swap","target":"root/Toolbar:0/Primary:0"}];
type Choice = { variant?: Variant };
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const value = props.values[field.name];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[props.variant ?? "default"], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

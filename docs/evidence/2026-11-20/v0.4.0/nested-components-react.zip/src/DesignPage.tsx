import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { DesignComponents } from "./FormaRuntime";
import Component0 from "./components/component-0e5cc22d679b6db0";
import Component1 from "./components/component-b031ec82e4bb6919";
import Component2 from "./components/component-8347912d409fa6d9";

const components = {"[\"5b799f22-403d-4e78-a422-6494f68be7d3\",\"component\"]": Component0, "[\"2a5d8f77-f657-44e6-9c39-fe9e23b68bf0\",\"component\"]": Component1, "[\"f60be417-5091-4d6e-a237-a8cd474398d8\",\"component\"]": Component2};
const nodes: RuntimeNode[] = [
  {
    "id": "Report",
    "name": "Report",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 420,
      "height": 240,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#16222a",
      "borderRadius": 0,
      "fontSize": 14,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 420,
      "height": 240
    },
    "children": [
      {
        "id": "76085c92-44aa-42f1-9037-078bd22fd063",
        "name": "Header",
        "key": "root",
        "component": "[\"5b799f22-403d-4e78-a422-6494f68be7d3\",\"component\"]",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 260,
          "height": 110,
          "position": "absolute",
          "left": 24,
          "top": 24,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#16222a",
          "borderRadius": 0,
          "fontSize": 14,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "eb5052a8-2b87-4b53-abc3-1d9b4e69f480",
            "name": "Toolbar",
            "key": "root/Toolbar:0",
            "component": "[\"2a5d8f77-f657-44e6-9c39-fe9e23b68bf0\",\"component\"]",
            "text": "",
            "type": "frame",
            "style": {
              "boxSizing": "border-box",
              "width": 200,
              "height": 75,
              "position": "absolute",
              "left": 24,
              "top": 24,
              "display": "block",
              "flexShrink": 0,
              "background": "#ffffff",
              "color": "#16222a",
              "borderRadius": 0,
              "fontSize": 14,
              "padding": 0,
              "border": 0,
              "fontFamily": "inherit",
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": [
              {
                "id": "23f2b2be-b2b4-474e-b4d5-462265609d17",
                "name": "Heading",
                "key": "root/Toolbar:0/Heading:0",
                "text": "团队概览",
                "type": "text",
                "style": {
                  "boxSizing": "border-box",
                  "width": 90,
                  "height": 32,
                  "position": "absolute",
                  "left": 0,
                  "top": 0,
                  "display": "block",
                  "flexShrink": 0,
                  "background": "transparent",
                  "color": "#16222a",
                  "borderRadius": 0,
                  "fontSize": 14,
                  "padding": 0,
                  "border": 0,
                  "fontFamily": "system-ui, sans-serif",
                  "fontWeight": 400,
                  "lineHeight": 1.4,
                  "letterSpacing": 0,
                  "whiteSpace": "pre-wrap",
                  "overflowWrap": "break-word",
                  "margin": 0
                },
                "children": []
              },
              {
                "id": "3b2c6b9a-fdfc-47df-b237-6a4ce9289682",
                "name": "Primary",
                "key": "root/Toolbar:0/Primary:0",
                "component": "[\"f60be417-5091-4d6e-a237-a8cd474398d8\",\"component\"]",
                "text": "",
                "type": "frame",
                "style": {
                  "boxSizing": "border-box",
                  "width": 90,
                  "height": 32,
                  "position": "absolute",
                  "left": 24,
                  "top": 24,
                  "display": "block",
                  "flexShrink": 0,
                  "background": "#ffffff",
                  "color": "#16222a",
                  "borderRadius": 0,
                  "fontSize": 14,
                  "padding": 0,
                  "border": 0,
                  "fontFamily": "inherit",
                  "whiteSpace": "pre-wrap",
                  "overflowWrap": "break-word",
                  "margin": 0
                },
                "children": [
                  {
                    "id": "ae539550-50c3-4b08-a3bc-3b4a580aab61",
                    "name": "AlternateMark",
                    "key": "slot-bebd3d0df4d46228",
                    "text": "新版标识",
                    "type": "text",
                    "style": {
                      "boxSizing": "border-box",
                      "width": 90,
                      "height": 32,
                      "position": "absolute",
                      "left": 0,
                      "top": 0,
                      "display": "block",
                      "flexShrink": 0,
                      "background": "transparent",
                      "color": "#16222a",
                      "borderRadius": 0,
                      "fontSize": 14,
                      "padding": 0,
                      "border": 0,
                      "fontFamily": "system-ui, sans-serif",
                      "fontWeight": 400,
                      "lineHeight": 1.4,
                      "letterSpacing": 0,
                      "whiteSpace": "pre-wrap",
                      "overflowWrap": "break-word",
                      "margin": 0
                    },
                    "children": []
                  },
                  {
                    "id": "6e1c0cd5-7357-475e-9fea-a4c68b1b17bb",
                    "name": "Dot",
                    "key": "slot-a428899318bd2e18",
                    "text": "",
                    "type": "ellipse",
                    "style": {
                      "boxSizing": "border-box",
                      "width": 8,
                      "height": 8,
                      "position": "absolute",
                      "left": 72,
                      "top": 0,
                      "display": "block",
                      "flexShrink": 0,
                      "background": "#ffffff",
                      "color": "#16222a",
                      "borderRadius": "50%",
                      "fontSize": 14,
                      "padding": 0,
                      "border": 0,
                      "fontFamily": "inherit",
                      "whiteSpace": "pre-wrap",
                      "overflowWrap": "break-word",
                      "margin": 0
                    },
                    "children": []
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":420,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ onAction }: { onAction?: DesignAction }) {
  return <DesignComponents.Provider value={components}><main style={pageStyle}>{nodes.map(node => <DesignNodeView key={node.id} node={node} onAction={onAction}/>)}</main></DesignComponents.Provider>;
}

import type { ExportedPage } from "./FileRouter";
export const pages: ExportedPage[] = [
  { id: "first", name: "页面 1", screens: [{"id":"Feedback","name":"Feedback"}], load: () => import("./Page1") }
];
export const start = "Feedback";

// Resolved default-mode values plus stable CSS names. Full collections, aliases and styles are in design-system.json.
export const tokens = {
  "bgCanvas": {
    "name": "Surface/Canvas",
    "type": "color",
    "value": "#0b0d14",
    "cssName": "--aura-bg-canvas"
  },
  "bgSurface": {
    "name": "Surface/Card",
    "type": "color",
    "value": "#131724",
    "cssName": "--aura-bg-surface"
  },
  "bgSubtle": {
    "name": "Surface/Subtle",
    "type": "color",
    "value": "#1a2033",
    "cssName": "--aura-bg-subtle"
  },
  "borderSubtle": {
    "name": "Border/Subtle",
    "type": "color",
    "value": "#262e45",
    "cssName": "--aura-border-subtle"
  },
  "textPrimary": {
    "name": "Text/Primary",
    "type": "color",
    "value": "#f5f7ff",
    "cssName": "--aura-text-primary"
  },
  "textSecondary": {
    "name": "Text/Secondary",
    "type": "color",
    "value": "#96a0bc",
    "cssName": "--aura-text-secondary"
  },
  "brandPrimary": {
    "name": "Brand/Primary",
    "type": "color",
    "value": "#7c5cff",
    "cssName": "--aura-brand-primary"
  },
  "brandSoft": {
    "name": "Brand/Soft",
    "type": "color",
    "value": "#221b47",
    "cssName": "--aura-brand-soft"
  },
  "statusGreen": {
    "name": "Status/Success",
    "type": "color",
    "value": "#22c55e",
    "cssName": "--aura-status-green"
  },
  "statusCyan": {
    "name": "Status/Cyan",
    "type": "color",
    "value": "#38bdf8",
    "cssName": "--aura-status-cyan"
  }
} as const;

import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { DesignComponents } from "./FormaRuntime";
import Component0 from "./components/component-3fb5c2ec90c70a02";
import Component1 from "./components/component-932c99e53dee68cf";

const components = {"[\"b83d8aea-49ff-44c5-91b6-2be310942c3a\",\"component\"]": Component0, "[\"66b8416a-36c9-4082-9634-ee35e0818acd\",\"component\"]": Component1};
const nodes: RuntimeNode[] = [
  {
    "id": "dashboard",
    "name": "通知面板",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 400,
      "height": 200,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 400,
      "height": 200
    },
    "children": [
      {
        "id": "3151b3b8-2ec9-49b8-be32-9f8124fa6106",
        "name": "通知徽标 · Busy / 宽版",
        "key": "root",
        "component": "[\"b83d8aea-49ff-44c5-91b6-2be310942c3a\",\"component\"]",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 232,
          "height": 44,
          "position": "absolute",
          "left": 24,
          "top": 24,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "187d65a1-69e2-4bc7-a580-dcae8dde3484",
            "name": "徽标文字",
            "key": "root/徽标文字:0",
            "text": "待发送",
            "type": "text",
            "style": {
              "boxSizing": "border-box",
              "width": 120,
              "height": 32,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "transparent",
              "color": "#202536",
              "borderRadius": 5,
              "fontSize": 16,
              "padding": 0,
              "border": 0,
              "fontFamily": "system-ui, sans-serif",
              "fontWeight": 400,
              "lineHeight": 1.4,
              "letterSpacing": 0,
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      },
      {
        "id": "ca44594b-d0bb-4e00-b644-c2b64f817671",
        "name": "警示徽标",
        "key": "root",
        "component": "[\"66b8416a-36c9-4082-9634-ee35e0818acd\",\"component\"]",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 190,
          "height": 44,
          "position": "absolute",
          "left": 24,
          "top": 24,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "eb0e1282-ae33-4428-994a-61df12fdfd7b",
            "name": "徽标文字",
            "key": "root/徽标文字:0",
            "text": "注意",
            "type": "text",
            "style": {
              "boxSizing": "border-box",
              "width": 140,
              "height": 44,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "transparent",
              "color": "#202536",
              "borderRadius": 5,
              "fontSize": 16,
              "padding": 0,
              "border": 0,
              "fontFamily": "system-ui, sans-serif",
              "fontWeight": 400,
              "lineHeight": 1.4,
              "letterSpacing": 0,
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":400,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ onAction }: { onAction?: DesignAction }) {
  return <DesignComponents.Provider value={components}><main style={pageStyle}>{nodes.map(node => <DesignNodeView key={node.id} node={node} onAction={onAction}/>)}</main></DesignComponents.Provider>;
}

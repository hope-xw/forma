import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "队列标签组";
export type Variant = "14a81789-7ca5-4814-b3f9-a1f24f2cdce7" | "fc5df03c-d2f2-4b3e-aa18-e0a639d108ba";
const variants: Record<Variant, RuntimeNode> = {
  "14a81789-7ca5-4814-b3f9-a1f24f2cdce7": {
    "id": "004a68af-047d-4558-aabc-aea935d15a81",
    "name": "队列标签组",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 140,
      "height": 44,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 140,
      "height": 44
    },
    "children": [
      {
        "id": "85d58af8-7bce-4620-b969-612a802a12b9",
        "name": "徽标文字",
        "key": "root/徽标文字:0",
        "text": "就绪",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  "fc5df03c-d2f2-4b3e-aa18-e0a639d108ba": {
    "id": "other-build",
    "name": "警示徽标",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 190,
      "height": 44,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 190,
      "height": 44
    },
    "children": [
      {
        "id": "other-label",
        "name": "徽标文字",
        "key": "root/徽标文字:0",
        "text": "注意",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 140,
          "height": 44,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
};
export type ComponentValues = {"文案"?: string};
const fields: {name: keyof ComponentValues; kind: string; target: string}[] = [{"name":"文案","kind":"text","target":"root/徽标文字:0"}];
export const variantProperties = {
  "14a81789-7ca5-4814-b3f9-a1f24f2cdce7": {
    "Tone": "Idle"
  },
  "fc5df03c-d2f2-4b3e-aa18-e0a639d108ba": {
    "Tone": "Warning"
  }
} as const;
export type VariantProperties = (typeof variantProperties)[Variant];
type Choice = { variant?: Variant; variantProperties?: never } | { variant?: never; variantProperties: VariantProperties };
function variantId(choice: Choice): Variant {
  if (!choice.variantProperties) return choice.variant ?? "14a81789-7ca5-4814-b3f9-a1f24f2cdce7";
  const wanted: Record<string,string> = choice.variantProperties;
  const matches = (Object.keys(variantProperties) as Variant[]).filter(id => {
    const props = Object.entries(variantProperties[id]);
    return props.length === Object.keys(wanted).length && props.every(([key,value]) => wanted[key] === value);
  });
  if (matches.length !== 1) throw Error(componentName + "：找不到唯一的变体属性组合，请检查属性或指定 variant。");
  return matches[0];
}
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const value = props.values[field.name];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[variantId(props)], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

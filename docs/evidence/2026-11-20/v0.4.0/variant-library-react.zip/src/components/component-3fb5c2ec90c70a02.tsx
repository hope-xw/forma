import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "通知徽标";
export type Variant = "default" | "5c53217b-48ee-4e43-b676-5c749cea1459" | "7031eb9f-c26b-43c5-99a0-b17fff36029e";
const variants: Record<Variant, RuntimeNode> = {
  "default": {
    "id": "master",
    "name": "通知徽标",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 140,
      "height": 44,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 140,
      "height": 44
    },
    "children": [
      {
        "id": "label",
        "name": "徽标文字",
        "key": "root/徽标文字:0",
        "text": "就绪",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  "5c53217b-48ee-4e43-b676-5c749cea1459": {
    "id": "1b3d53e6-0663-4344-adde-522cf216e482",
    "name": "通知徽标 · Busy / Regular",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 140,
      "height": 44,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 140,
      "height": 44
    },
    "children": [
      {
        "id": "2e388fd7-5958-4693-8f63-b5796b97780d",
        "name": "徽标文字",
        "key": "root/徽标文字:0",
        "text": "就绪",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  "7031eb9f-c26b-43c5-99a0-b17fff36029e": {
    "id": "9b9fef23-c9ef-43d9-ac76-6af50e6b112e",
    "name": "通知徽标 · Busy / 宽版",
    "key": "root",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 232,
      "height": 44,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#202536",
      "borderRadius": 5,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 232,
      "height": 44
    },
    "children": [
      {
        "id": "c7be02ef-c387-4e0a-9bb9-bd298782e6ca",
        "name": "徽标文字",
        "key": "root/徽标文字:0",
        "text": "就绪",
        "type": "text",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 32,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#202536",
          "borderRadius": 5,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "system-ui, sans-serif",
          "fontWeight": 400,
          "lineHeight": 1.4,
          "letterSpacing": 0,
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
};
export type ComponentValues = {"文案"?: string};
const fields: {name: keyof ComponentValues; kind: string; target: string}[] = [{"name":"文案","kind":"text","target":"root/徽标文字:0"}];
export const variantProperties = {
  "default": {
    "State": "Normal",
    "尺寸": "Regular"
  },
  "5c53217b-48ee-4e43-b676-5c749cea1459": {
    "State": "Busy",
    "尺寸": "Regular"
  },
  "7031eb9f-c26b-43c5-99a0-b17fff36029e": {
    "State": "Busy",
    "尺寸": "宽版"
  }
} as const;
export type VariantProperties = (typeof variantProperties)[Variant];
type Choice = { variant?: Variant; variantProperties?: never } | { variant?: never; variantProperties: VariantProperties };
function variantId(choice: Choice): Variant {
  if (!choice.variantProperties) return choice.variant ?? "default";
  const wanted: Record<string,string> = choice.variantProperties;
  const matches = (Object.keys(variantProperties) as Variant[]).filter(id => {
    const props = Object.entries(variantProperties[id]);
    return props.length === Object.keys(wanted).length && props.every(([key,value]) => wanted[key] === value);
  });
  if (matches.length !== 1) throw Error(componentName + "：找不到唯一的变体属性组合，请检查属性或指定 variant。");
  return matches[0];
}
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const value = props.values[field.name];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[variantId(props)], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

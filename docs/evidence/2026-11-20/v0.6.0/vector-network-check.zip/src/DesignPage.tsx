import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";

const nodes: RuntimeNode[] = [
  {
    "id": "board",
    "name": "Board",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 400,
      "height": 300,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#334455",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 400,
      "height": 300
    },
    "children": [
      {
        "id": "glyph",
        "name": "Split badge",
        "text": "",
        "type": "vector",
        "style": {
          "boxSizing": "border-box",
          "width": 158.5,
          "height": 100.5,
          "position": "absolute",
          "left": 66,
          "top": 50,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#334455",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "vector": {
          "width": 158.5,
          "height": 100.5,
          "paths": [
            {
              "d": "M0 0 L140 0 L149 100 Z",
              "junctions": [
                {
                  "contour": 0,
                  "anchor": 0,
                  "id": "d52a30ef-0f2a-4ca7-8601-4fb951b1523f"
                },
                {
                  "contour": 0,
                  "anchor": 2,
                  "id": "61657574-8db9-4c46-b5ec-aaad659cd753"
                }
              ],
              "fill": true,
              "fillColor": "#1177cc",
              "fillOpacity": 1,
              "strokeWidth": 0
            },
            {
              "d": "M149 100 L0 100 L0 0 Z",
              "junctions": [
                {
                  "contour": 0,
                  "anchor": 0,
                  "id": "61657574-8db9-4c46-b5ec-aaad659cd753"
                },
                {
                  "contour": 0,
                  "anchor": 2,
                  "id": "d52a30ef-0f2a-4ca7-8601-4fb951b1523f"
                }
              ],
              "fill": true,
              "fillColor": "#ffaa22",
              "fillOpacity": 1,
              "strokeWidth": 0
            },
            {
              "d": "M149 100 L158 50",
              "junctions": [
                {
                  "contour": 0,
                  "anchor": 0,
                  "id": "61657574-8db9-4c46-b5ec-aaad659cd753"
                }
              ],
              "fill": false,
              "strokeColor": "#ffaa22",
              "strokeWidth": 1
            }
          ]
        },
        "children": []
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":400,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ onAction }: { onAction?: DesignAction }) {
  return <main style={pageStyle}>{nodes.map(node => <DesignNodeView key={node.id} node={node} onAction={onAction}/>)}</main>;
}

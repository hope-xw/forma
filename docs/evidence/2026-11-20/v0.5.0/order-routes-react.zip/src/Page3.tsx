import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { PrototypePlayer } from "./PrototypePlayer";
import type { Program } from "./prototype-machine";

const nodes: RuntimeNode[] = [
  {
    "id": "Sheet",
    "name": "Sheet",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 260,
      "height": 210,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffee",
      "color": "#131722",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 260,
      "height": 210
    },
    "children": [
      {
        "id": "Inspect",
        "name": "Inspect",
        "text": "Inspect",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 45,
          "position": "absolute",
          "left": 15,
          "top": 95,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#ffffee",
          "color": "#131722",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      },
      {
        "id": "Dismiss",
        "name": "Dismiss",
        "text": "Dismiss",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 45,
          "position": "absolute",
          "left": 15,
          "top": 15,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#96ce99",
          "color": "#131722",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  {
    "id": "Confirm",
    "name": "Confirm",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 260,
      "height": 210,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffee",
      "color": "#131722",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 260,
      "height": 210
    },
    "children": [
      {
        "id": "Accept",
        "name": "Accept",
        "text": "Accept",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 45,
          "position": "absolute",
          "left": 15,
          "top": 15,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#96ce99",
          "color": "#131722",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":390,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;
const program: Program = {
  "flows": [
    {
      "id": "Sheet",
      "name": "Sheet"
    }
  ],
  "rules": {
    "Inspect": {
      "actions": [
        {
          "kind": "overlay",
          "target": "Confirm",
          "position": "center"
        }
      ]
    },
    "Accept": {
      "actions": [
        {
          "kind": "close"
        }
      ]
    },
    "Dismiss": {
      "actions": [
        {
          "kind": "close"
        }
      ]
    }
  },
  "variables": {},
  "cssNames": {}
};
export const flows = program.flows;

export default function DesignPage({ flow = flows[0].id, onAction }: { flow?: string; onAction?: DesignAction }) {
  return <PrototypePlayer key={flow} nodes={nodes} program={program} start={nodes.some(n => n.id === flow) ? flow : flows[0].id} onAction={onAction} style={pageStyle}/>;
}

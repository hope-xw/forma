import type { DesignAction } from "./FormaRuntime";
import { FileRouter } from "./FileRouter";
import { pages, start } from "./pages";
export default function DesignPage({ screen, onAction }: {screen?: string; onAction?: DesignAction}) { return <FileRouter pages={pages} start={start} screen={screen} onAction={onAction}/>; }

import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";

const nodes: RuntimeNode[] = [];
const pageStyle = {"position":"relative","minWidth":390,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ flow, onAction }: { flow?: string; onAction?: DesignAction }) {
  const screen = nodes.find(n => n.id === flow) ?? nodes[0];
  return <main style={{...pageStyle, minWidth: 0, minHeight: 0}}>{screen && <DesignNodeView node={{...screen, style:{...screen.style, position:'relative', left:0, top:0}}} onAction={onAction}/>}</main>;
}

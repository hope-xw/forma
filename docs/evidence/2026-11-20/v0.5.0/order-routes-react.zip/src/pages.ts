import type { ExportedPage } from "./FileRouter";
export const pages: ExportedPage[] = [
  { id: "web", name: "Web", screens: [{"id":"Start","name":"Start"}], load: () => import("./Page1") },
  { id: "mobile", name: "Mobile", screens: [{"id":"Detail","name":"Detail"}], load: () => import("./Page2") },
  { id: "sheets", name: "Overlays", screens: [{"id":"Sheet","name":"Sheet"},{"id":"Confirm","name":"Confirm"}], load: () => import("./Page3") },
  { id: "blank", name: "Empty page", screens: [], load: () => import("./Page4") }
];
export const start = "Start";

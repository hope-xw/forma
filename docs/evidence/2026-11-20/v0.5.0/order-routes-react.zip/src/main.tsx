import { useSyncExternalStore } from "react";
import { createRoot } from "react-dom/client";
import DesignPage from "./DesignPage";
import "./tokens.css";

function subscribe(change: () => void) {
  window.addEventListener("hashchange", change);
  return () => window.removeEventListener("hashchange", change);
}
function Orders() {
  const route = useSyncExternalStore(subscribe, () => location.hash);
  const detail = route === "#/orders/42";
  return <>
    <nav aria-label="订单"><a href="#/orders">订单列表</a> <a href="#/orders/42">查看订单 42</a></nav>
    <DesignPage screen={detail ? "Detail" : "Start"} />
  </>;
}
createRoot(document.getElementById("root")!).render(<Orders />);

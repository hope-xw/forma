# Forma React export

Run `npm install` then `npm run dev`. Verify with `npm run build`.

Reusable component modules live in src/components for the components used in your file. Import a module and pass instanceId, variant, and optional text overrides keyed by template key. The generated pages use the same modules with their exact instance overrides.

Place your business handlers in src/business.ts. To update a design, ZIP the project source with forma-project.json (exclude dependencies, dist and .git). In Forma choose 文件菜单 → 更新已有 React 工程 and select that ZIP. The new archive preserves your entry point, configuration and custom files. A conflict in generated code blocks the merge and names the file.

DesignPage accepts an optional `onAction(id, value)` callback for business integration. Native inputs, switches, checkboxes, sliders, steppers, segmented controls and progress semantics are implemented. Declared prototype flows include navigation, overlays, history, scrolling, conditions, variables and ordered actions. Wire business services and system sharing through the application.

The exporter writes fixed, intrinsic and fill sizes, text runs, horizontal wrapping, responsive grids, free-frame constraints, image crops and vector paths. Fixed-column grids can change column count and spacing at their configured container width. Original Forma component geometry and system font fallbacks are included; no Apple fonts, SF Symbols or Apple source resources are bundled. The serialized design is included for reopening in Forma. Design-system exports include collections, modes, aliases, style definitions and bindings in design-system.json and design.forma.json, plus CSS and TypeScript tokens. Supported paint, numeric and typography bindings use CSS variables. String content, boolean visibility and native control geometry are resolved for the exported modes; those changes require re-export. Element mode overrides are emitted as scoped CSS custom properties.

The complete file is split into lazy page modules. Open /#screens for the artboard directory, or /#screen=<URL-encoded layer ID> for a direct link. src/pages.ts maps each page and artboard to its module. Pass a stable screen ID to <DesignPage screen={screenId}/> to use an application-owned route without changing its URL. Import a page component and pass flow and onAction to embed it without the file router.

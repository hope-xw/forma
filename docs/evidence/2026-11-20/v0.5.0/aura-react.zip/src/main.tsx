import './tokens.css';
import { createRoot } from 'react-dom/client';
import DesignPage from './DesignPage';
import { onDesignAction } from './business';
createRoot(document.getElementById('root')!).render(<DesignPage onAction={onDesignAction}/>);

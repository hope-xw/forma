import type { DesignAction } from './FormaRuntime';

/** Connect design node IDs to your application here. */
export const onDesignAction: DesignAction = (_id, _value) => {};

// Resolved default-mode values plus stable CSS names. Full collections, aliases and styles are in design-system.json.
export const tokens = {
  "bgCanvas": {
    "name": "Surface/Canvas",
    "type": "color",
    "value": "#f7f8fc",
    "cssName": "--aura-bg-canvas"
  },
  "bgSurface": {
    "name": "Surface/Card",
    "type": "color",
    "value": "#ffffff",
    "cssName": "--aura-bg-surface"
  },
  "bgSubtle": {
    "name": "Surface/Subtle",
    "type": "color",
    "value": "#f1f3f9",
    "cssName": "--aura-bg-subtle"
  },
  "borderSubtle": {
    "name": "Border/Subtle",
    "type": "color",
    "value": "#e3e7f2",
    "cssName": "--aura-border-subtle"
  },
  "textPrimary": {
    "name": "Text/Primary",
    "type": "color",
    "value": "#111629",
    "cssName": "--aura-text-primary"
  },
  "textSecondary": {
    "name": "Text/Secondary",
    "type": "color",
    "value": "#5c6682",
    "cssName": "--aura-text-secondary"
  },
  "brandPrimary": {
    "name": "Brand/Primary",
    "type": "color",
    "value": "#6344f5",
    "cssName": "--aura-brand-primary"
  },
  "brandSoft": {
    "name": "Brand/Soft",
    "type": "color",
    "value": "#eeebff",
    "cssName": "--aura-brand-soft"
  },
  "statusGreen": {
    "name": "Status/Success",
    "type": "color",
    "value": "#16a34a",
    "cssName": "--aura-status-green"
  },
  "statusCyan": {
    "name": "Status/Cyan",
    "type": "color",
    "value": "#0284c7",
    "cssName": "--aura-status-cyan"
  }
} as const;

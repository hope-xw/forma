import {
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
} from "react";
import {
  DesignNodeView,
  InteractionContext,
  type DesignAction,
  type RuntimeNode,
} from "./FormaRuntime";
import { act, startFlow, trigger, type Program } from "./prototype-machine";

export function PrototypePlayer({
  nodes,
  program,
  start,
  onAction,
  fit,
  previewWidth,
  style,
}: {
  nodes: RuntimeNode[];
  program: Program;
  start: string;
  onAction?: DesignAction;
  fit?: { width: number; height: number };
  previewWidth?: number;
  style?: CSSProperties;
}) {
  const [session, setSession] = useState(() => startFlow(program, start));
  const screen = nodes.find((n) => n.id === session.screen);
  const host = useRef<HTMLDivElement>(null);
  const scroll = useRef(new Map<string, [number, number]>());
  const wired = useMemo(() => new Set(Object.keys(program.rules)), [program]);
  const reset = useRef(session.resetCount);
  const previousTop = useRef("");
  const previousDepth = useRef(0);
  const top = session.overlays.at(-1)?.target ?? session.screen;
  const opener = useRef(new Map<string, string>());
  const close = () => setSession((s) => act(program, s, [{ kind: "close" }]));
  const activate: DesignAction = (id, value) => {
    setSession((s) => trigger(program, s, id, value));
    if (host.current) opener.current.set(top, id);
    onAction?.(id, value);
  };
  useLayoutEffect(() => {
    if (reset.current !== session.resetCount) {
      scroll.current.clear();
      reset.current = session.resetCount;
    }
    const region = host.current;
    if (!region) return;
    const elements = Array.from(
      region.querySelectorAll<HTMLElement>("[data-design-id]"),
    );
    for (const element of elements) {
      const id = element.dataset.designId!;
      if (
        session.scrollReset &&
        element.closest("[data-screen]")?.getAttribute("data-screen") ===
          session.scrollReset
      )
        scroll.current.delete(id);
      const [x, y] = scroll.current.get(id) ?? [0, 0];
      if (element.scrollTop !== y || element.scrollLeft !== x)
        element.scrollTo(x, y);
    }
    if (session.scrollTarget)
      elements
        .find((el) => el.dataset.designId === session.scrollTarget)
        ?.scrollIntoView({ block: "nearest", inline: "nearest" });
    if (
      top !== previousTop.current &&
      (previousTop.current || session.overlays.length)
    ) {
      const scope = region.querySelector<HTMLElement>("[data-active-screen]");
      const enteringOverlay = session.overlays.length > previousDepth.current;
      const last =
        !enteringOverlay &&
        elements.find(
          (el) =>
            scope?.contains(el) &&
            el.dataset.designId === opener.current.get(top),
        );
      const target =
        last && scope?.contains(last)
          ? last.matches("[tabindex],button")
            ? last
            : last.querySelector<HTMLElement>("button,input")
          : null;
      (target ?? scope)?.focus({ preventScroll: true });
    }
    previousDepth.current = session.overlays.length;
    previousTop.current = top;
  }, [session, top]);
  if (!screen) return null;
  const responsive = screen.style.width === "100%";
  const designWidth =
    screen.geometry?.width ?? (Number(screen.style.width) || 390);
  const width = responsive && fit && previewWidth ? previewWidth : designWidth;
  const height =
    screen.geometry?.height ?? (Number(screen.style.height) || 844);
  const scale = fit ? Math.min(1, fit.width / width, fit.height / height) : 1;
  const variables = Object.fromEntries(
    Object.entries(session.changes).map(([key, value]) => [
      program.cssNames[key],
      String(value),
    ]),
  );
  const render = (node: RuntimeNode, overlay: boolean, index: number) => {
    const active = overlay
      ? index === session.overlays.length - 1
      : !session.overlays.length;
    const layer = {
      ...node,
      style: { ...node.style, left: 0, top: 0, position: "relative" as const },
    };
    const region = (
      <div
        data-screen={node.id}
        data-active-screen={active ? "" : undefined}
        inert={!active}
        role={overlay ? "dialog" : undefined}
        aria-modal={overlay && active ? true : undefined}
        aria-label={node.name}
        tabIndex={-1}
        style={{
          position: "relative",
          outline: "none",
          maxWidth: "100%",
          maxHeight: "100%",
          overflow: "auto",
        }}
        onKeyDown={(e) => {
          if (!overlay || !active) return;
          if (e.key === "Escape") {
            e.preventDefault();
            e.stopPropagation();
            close();
          }
          if (e.key === "Tab") {
            const controls = Array.from(
              e.currentTarget.querySelectorAll<HTMLElement>(
                'button:not(:disabled),input:not(:disabled),[tabindex="0"]',
              ),
            ).filter((el) => el.getClientRects().length);
            if (!controls.length) {
              e.preventDefault();
              return;
            }
            const edge = e.shiftKey ? controls[0] : controls.at(-1);
            if (
              document.activeElement === edge ||
              (e.shiftKey && document.activeElement === e.currentTarget)
            ) {
              e.preventDefault();
              (e.shiftKey ? controls.at(-1) : controls[0])?.focus();
            }
          }
        }}
      >
        <DesignNodeView node={layer} onAction={activate} />
      </div>
    );
    return overlay ? (
      <div
        key={node.id}
        style={{
          position: "absolute",
          inset: 0,
          background: "#0006",
          display: "flex",
          justifyContent: "center",
          alignItems:
            session.overlays[index].position === "bottom" ? "end" : "center",
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget && active) close();
        }}
      >
        {region}
      </div>
    ) : (
      region
    );
  };
  return (
    <div
      style={{
        width: responsive && !fit ? "100%" : width * scale,
        height: height * scale,
        position: "relative",
      }}
    >
      <div
        ref={host}
        style={{
          ...style,
          ...variables,
          position: "relative",
          width: responsive && !fit ? "100%" : width,
          height,
          minWidth: 0,
          minHeight: 0,
          overflow: "hidden",
          transform: "scale(" + scale + ")",
          transformOrigin: "top left",
        }}
        onScrollCapture={(e) => {
          const el = e.target as HTMLElement;
          if (el.dataset.designId)
            scroll.current.set(el.dataset.designId, [
              el.scrollLeft,
              el.scrollTop,
            ]);
        }}
      >
        <InteractionContext.Provider
          value={{
            wired,
            controls: session.controls,
            changes: session.changes,
          }}
        >
          <div key={session.screen + ":" + session.resetCount}>
            {render(screen, false, 0)}
          </div>
          {session.overlays.map((overlay, index) => {
            const node = nodes.find((n) => n.id === overlay.target);
            return node && render(node, true, index);
          })}
        </InteractionContext.Provider>
      </div>
    </div>
  );
}

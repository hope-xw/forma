import type { ExportedPage } from "./FileRouter";
export const pages: ExportedPage[] = [
  { id: "first", name: "页面 1", screens: [{"id":"d7deca5d-fe75-4e08-8d0d-ec18fb95d9f2","name":"News tag"}], load: () => import("./Page1") }
];
export const start = "d7deca5d-fe75-4e08-8d0d-ec18fb95d9f2";

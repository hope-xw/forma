import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { DesignComponents } from "./FormaRuntime";
import Component0 from "./components/component-a793587faf5a5d55";

const components = {"[\"d14e7af4-68d9-4b57-a0fc-faea453cf0fd\",\"component\"]": Component0};
const nodes: RuntimeNode[] = [
  {
    "id": "d7deca5d-fe75-4e08-8d0d-ec18fb95d9f2",
    "name": "News tag",
    "key": "root",
    "component": "[\"d14e7af4-68d9-4b57-a0fc-faea453cf0fd\",\"component\"]",
    "text": "库存 12",
    "type": "text",
    "style": {
      "boxSizing": "border-box",
      "width": 100,
      "height": 48,
      "position": "absolute",
      "left": 651.4285714285714,
      "top": 622.8571428571429,
      "display": "block",
      "flexShrink": 0,
      "background": "transparent",
      "color": "#222222",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "system-ui, sans-serif",
      "fontWeight": 400,
      "lineHeight": 1.4,
      "letterSpacing": 0,
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "children": []
  }
];
const pageStyle = {"--token-brand":"#635bff","position":"relative","minWidth":751.4285714285714,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ flow, onAction }: { flow?: string; onAction?: DesignAction }) {
  const screen = nodes.find(n => n.id === flow) ?? nodes[0];
  return <DesignComponents.Provider value={components}><main style={{...pageStyle, minWidth: 0, minHeight: 0}}>{screen && <DesignNodeView node={{...screen, style:{...screen.style, position:'relative', left:0, top:0}}} onAction={onAction}/>}</main></DesignComponents.Provider>;
}

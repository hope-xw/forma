import { DesignNodeContent, instanceTemplate, type RuntimeNode, type DesignAction } from "../FormaRuntime";
import "../tokens.css";
export const componentName = "News tag";
export type Variant = "default";
const variants: Record<Variant, RuntimeNode> = {
  "default": {
    "id": "badge",
    "name": "News tag",
    "key": "root",
    "text": "Updated",
    "type": "text",
    "style": {
      "boxSizing": "border-box",
      "width": 100,
      "height": 48,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "transparent",
      "color": "#222222",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "system-ui, sans-serif",
      "fontWeight": 400,
      "lineHeight": 1.4,
      "letterSpacing": 0,
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "children": []
  }
};
export type ComponentValues = {"业务标签"?: string; "标签"?: string};
const fields: {names: (keyof ComponentValues)[]; kind: string; target: string}[] = [{"names":["业务标签","标签"],"kind":"text","target":"root"}];
type Choice = { variant?: Variant };
type Props = { node: RuntimeNode; onAction?: DesignAction } | (Choice & { instanceId: string; values?: ComponentValues; text?: Record<string, string>; onAction?: DesignAction });
export default function DesignComponent(props: Props) {
  const text: Record<string,string> = "text" in props ? {...props.text} : {};
  const visibility: Record<string,boolean> = {};
  const slots: Record<string,import("react").ReactNode> = {};
  if ("values" in props && props.values) for (const field of fields) {
    const key = field.names.find(name => Object.prototype.hasOwnProperty.call(props.values, name));
    if (key === undefined) continue;
    const value = props.values[key];
    if (typeof value === "string" && field.kind === "text") text[field.target] = value;
    if (typeof value === "boolean" && field.kind === "visible") visibility[field.target] = value;
    if (field.kind === "swap" && value !== undefined) slots[field.target] = value;
  }
  const node = "node" in props ? props.node : instanceTemplate(variants[props.variant ?? "default"], props.instanceId, text, visibility, slots);
  return <DesignNodeContent node={node} onAction={props.onAction}/>;
}

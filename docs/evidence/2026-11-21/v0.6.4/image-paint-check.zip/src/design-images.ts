export default {
  "img-132e59a3b08c9c87fed48f34e56352f1f3c9539222b13dfacf58caeb37693d2d": { data: new URL("./assets/img-132e59a3b08c9c87fed48f34e56352f1f3c9539222b13dfacf58caeb37693d2d.png", import.meta.url).href },
};

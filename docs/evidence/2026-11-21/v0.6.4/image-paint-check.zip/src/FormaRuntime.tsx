import {
  createContext,
  useRef,
  useLayoutEffect,
  useContext,
  useState,
  type CSSProperties,
  type ComponentType,
  type ReactNode,
} from "react";
export interface RuntimeControl {
  kind:
    | "button"
    | "switch"
    | "checkbox"
    | "textfield"
    | "slider"
    | "stepper"
    | "segmented"
    | "progress";
  label: string;
  value: string | number | boolean;
  disabled?: boolean;
  min?: number;
  max?: number;
  step?: number;
  options?: string[];
  palette?: { accent: string; track: string; surface: string; border?: string };
}
export interface RuntimeNode {
  slotContent?: ReactNode;
  id: string;
  name: string;
  key?: string;
  component?: string;
  visibleDisplay?: CSSProperties["display"];
  text: string;
  parts?: { text: string; style: CSSProperties }[];
  type: string;
  style: CSSProperties & { [property: `--${string}`]: string | number };
  control?: RuntimeControl;
  gridBreakpoint?: {
    rules: {
      maxWidth: number;
      columns?: number;
      gap?: number;
      rowGap?: number;
      padding?: number;
      radius?: number;
      opacity?: number;
      fill?: string;
    }[];
    hasExplicitRowGap: boolean;
    variable: string;
  };
  geometry?: { width: number; height: number };
  bindings?: {
    text?: string;
    visible?: string;
    display?: CSSProperties["display"];
  };
  image?: {
    assetId: string;
    fit: "cover" | "contain" | "fill" | "tile";
    tileSize?: readonly [number, number];
    filter?: string;
    zoom: number;
    x: number;
    y: number;
    source?: string;
  };
  vector?: {
    stretch?: true;
    radial?:
      | { kind: "star"; points: number; innerRatio: number }
      | { kind: "polygon"; points: number };
    width: number;
    height: number;
    paths: {
      junctions?: { contour: number; anchor: number; id: string }[];
      d: string;
      fill: boolean;
      strokeWidth: number;
      fillColor?: string;
      strokeColor?: string;
      fillRule?: "nonzero" | "evenodd";
      lineCap?: "butt" | "round" | "square";
      lineJoin?: "miter" | "bevel" | "round";
      opacity?: number;
      fillOpacity?: number;
      strokeOpacity?: number;
    }[];
  };
  children: RuntimeNode[];
}
export type DesignAction = (
  id: string,
  value: string | number | boolean,
) => void;
const hitArea: CSSProperties = {
  position: "absolute",
  inset: 0,
  width: "100%",
  height: "100%",
  padding: 0,
  margin: 0,
  border: 0,
  borderRadius: "inherit",
  background: "transparent",
  color: "transparent",
  cursor: "pointer",
  font: "inherit",
};
type ControlValue = string | number | boolean;
export const ImageResources = createContext<Record<string, { data: string }>>(
  {},
);
// stackPaints emits the visible overlays first and the base fill last. Split
// only between layers, since gradients and token expressions also use commas.
export function separateImageOverlay(style: CSSProperties) {
  const background = style.background;
  if (typeof background !== "string") return;
  let depth = 0;
  for (let i = background.length - 1; i >= 0; i--) {
    if (background[i] === ")") depth++;
    else if (background[i] === "(") depth--;
    else if (background[i] === "," && depth === 0) {
      style.background = background.slice(i + 1).trimStart();
      style.isolation = "isolate";
      return background.slice(0, i);
    }
  }
}
export function ImagePaint({
  paint,
  source,
  overlay,
}: {
  paint: NonNullable<RuntimeNode["image"]>;
  source?: string;
  overlay?: string;
}) {
  const resources = useContext(ImageResources);
  const src = source ?? paint.source ?? resources[paint.assetId]?.data;
  if (!src && !overlay) return null;
  const position = paint.x + "% " + paint.y + "%";
  return (
    <span
      aria-hidden="true"
      style={{
        display: "block",
        position: "absolute",
        inset: 0,
        overflow: "hidden",
        borderRadius: "inherit",
        pointerEvents: "none",
        zIndex: overlay ? -1 : undefined,
      }}
    >
      {src &&
        (paint.fit === "tile" ? (
          <span
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage: `url(${JSON.stringify(src)})`,
              backgroundRepeat: "repeat",
              backgroundSize: paint.tileSize?.map((n) => n + "px").join(" "),
              backgroundPosition: position,
              filter: paint.filter,
            }}
          />
        ) : (
          <img
            src={src}
            alt=""
            draggable={false}
            style={{
              display: "block",
              width: "100%",
              height: "100%",
              filter: paint.filter,
              objectFit: paint.fit,
              objectPosition: position,
              transform: "scale(" + paint.zoom + ")",
              transformOrigin: position,
            }}
          />
        ))}
      {overlay && (
        <span style={{ position: "absolute", inset: 0, background: overlay }} />
      )}
    </span>
  );
}
export const InteractionContext = createContext<{
  wired: ReadonlySet<string>;
  rules?: Record<string, { trigger?: "click" | "hover" | "delay" }>;
  controls: Record<string, ControlValue>;
  changes: Record<string, ControlValue>;
} | null>(null);
export function vectorPathProps(
  path: NonNullable<RuntimeNode["vector"]>["paths"][number],
) {
  return {
    d: path.d,
    fill: path.fill ? (path.fillColor ?? "currentColor") : "none",
    stroke: path.strokeWidth ? (path.strokeColor ?? "currentColor") : "none",
    strokeWidth: path.strokeWidth,
    style: {
      strokeWidth: `var(--forma-vector-stroke-width, ${path.strokeWidth}px)`,
    },
    fillRule: path.fillRule,
    opacity: path.opacity,
    fillOpacity: path.fillOpacity,
    strokeOpacity: path.strokeOpacity,
    strokeLinecap: path.lineCap ?? "round",
    strokeLinejoin: path.lineJoin ?? "round",
  };
}
function Vector({ node }: { node: RuntimeNode }) {
  return node.vector ? (
    <svg
      width="100%"
      height="100%"
      preserveAspectRatio={node.vector.stretch ? "none" : undefined}
      viewBox={`0 0 ${node.vector.width} ${node.vector.height}`}
      aria-hidden="true"
      style={{ display: "block" }}
    >
      {node.vector.paths.map((p, i) => (
        <path key={i} {...vectorPathProps(p)} />
      ))}
    </svg>
  ) : null;
}
/** The design width is the layout border box, independent of canvas zoom. */
export function useContainerLayout(rule: RuntimeNode["gridBreakpoint"]) {
  const ref = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState<number>();
  const enabled = !!rule;
  useLayoutEffect(() => {
    const el = ref.current;
    if (!enabled || !el) return;
    setWidth(el.offsetWidth);
    const observer = new ResizeObserver(([entry]) =>
      setWidth(entry.borderBoxSize?.[0]?.inlineSize ?? el.offsetWidth),
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [enabled]);
  const active =
    width === undefined
      ? undefined
      : rule?.rules.find((r) => width <= r.maxWidth);
  const style: RuntimeNode["style"] = {};
  if (rule && active) {
    const { columns, padding, gap, rowGap } = active;
    if (columns !== undefined) {
      style[rule.variable as `--${string}`] = String(columns);
      style[(rule.variable + "-tracks") as `--${string}`] =
        "repeat(" + columns + ",minmax(0,1fr))";
    }
    if (active.radius !== undefined) style.borderRadius = active.radius;
    if (active.opacity !== undefined) style.opacity = active.opacity;
    if (active.fill !== undefined) style.background = active.fill;
    if (padding !== undefined) style.padding = padding;
    if (gap !== undefined) {
      style.columnGap = gap;
      if (!rule.hasExplicitRowGap) style.rowGap = gap;
    }
    if (rowGap !== undefined) style.rowGap = rowGap;
  }
  function apply<T extends CSSProperties>(base: T): CSSProperties {
    if (!rule && base.gap === undefined) return base;
    // React cannot restore a shorthand after it has cleared an overlapping longhand.
    const { gap, ...rest } = base;
    return {
      ...rest,
      columnGap: base.columnGap ?? gap,
      rowGap: base.rowGap ?? gap,
      ...style,
    };
  }
  return { ref, apply };
}

export type DesignNodeProps = { node: RuntimeNode; onAction?: DesignAction };
export const DesignComponents = createContext<
  Record<string, ComponentType<DesignNodeProps>>
>({});
export function DesignNodeView(props: DesignNodeProps) {
  const components = useContext(DesignComponents);
  const Component = props.node.component && components[props.node.component];
  return Component ? (
    <Component {...props} />
  ) : (
    <DesignNodeContent {...props} />
  );
}
export function instanceTemplate(
  node: RuntimeNode,
  instanceId: string,
  text: Record<string, string> = {},
  visibility: Record<string, boolean> = {},
  slots: Record<string, ReactNode> = {},
): RuntimeNode {
  function build(layer: RuntimeNode, root: boolean): RuntimeNode {
    const override =
      layer.key !== undefined && Object.hasOwn(text, layer.key)
        ? text[layer.key]
        : undefined;
    const visible =
      layer.key === undefined
        ? undefined
        : Object.hasOwn(visibility, layer.key)
          ? visibility[layer.key]
          : undefined;
    return {
      ...layer,
      id: root ? instanceId : instanceId + "/" + (layer.key ?? layer.id),
      ...(override === undefined ? {} : { text: override, parts: undefined }),
      ...(layer.key !== undefined && Object.hasOwn(slots, layer.key)
        ? { slotContent: slots[layer.key] }
        : {}),
      style: {
        ...layer.style,
        ...(root ? { position: "relative", left: 0, top: 0 } : {}),
        ...(visible === undefined
          ? {}
          : {
              display: visible
                ? (layer.visibleDisplay ?? layer.style.display)
                : "none",
            }),
      },
      children: layer.children.map((child) => build(child, false)),
    };
  }
  return build(node, true);
}
export function DesignNodeContent({
  node,
  onAction,
}: {
  node: RuntimeNode;
  onAction?: DesignAction;
}) {
  const layout = useContainerLayout(node.gridBreakpoint);
  const c = node.control;
  const session = useContext(InteractionContext);
  const [localValue, setValue] = useState<ControlValue>(c?.value ?? "");
  const [localActivated, setActivated] = useState(false);
  const remote = session?.controls[node.id];
  const value = remote ?? localValue,
    activated = remote !== undefined || localActivated;
  const wired = session?.wired.has(node.id);
  const event = session?.rules?.[node.id]?.trigger ?? "click";
  const hotspot = !c && wired && event === "click";
  const change = (next: string | number | boolean) => {
    if (c?.disabled) return;
    setActivated(true);
    setValue(next);
    onAction?.(node.id, next);
  };
  const width = node.geometry?.width ?? (Number(node.style.width) || 1),
    height = node.geometry?.height ?? (Number(node.style.height) || 1);
  const min = c?.min ?? 0,
    max = c?.max ?? 100,
    step = c?.step ?? 1;
  const fraction = Math.min(
    1,
    Math.max(0, (Number(value) - min) / (max - min || 1)),
  );
  const base = { ...node.style, margin: 0 };
  const overlay =
    node.image && node.slotContent === undefined
      ? separateImageOverlay(base)
      : undefined;
  const style = layout.apply(base);
  if (node.style["--forma-hide-blur"]) delete style.filter;
  if (node.style["--forma-hide-backdrop"]) {
    delete style.backdropFilter;
    delete style.WebkitBackdropFilter;
  }
  const visible =
    node.bindings?.visible && session?.changes[node.bindings.visible];
  if (typeof visible === "boolean")
    style.display = visible
      ? style.WebkitLineClamp
        ? "-webkit-box"
        : node.type === "text" && style.flexDirection === "column"
          ? "flex"
          : (node.bindings?.display ?? "block")
      : "none";
  const boundText = node.bindings?.text && session?.changes[node.bindings.text];
  const text = typeof boundText === "string" ? boundText : node.text;
  if (activated && (c?.kind === "switch" || c?.kind === "checkbox"))
    style.background = value ? c.palette?.accent : c.palette?.track;
  if (activated && c?.kind === "checkbox")
    style.border = value ? 0 : `2px solid ${c.palette?.border ?? "#a0acc0"}`;
  const showPlaceholder =
    c?.kind === "textfield" && c.value === "" && value === "";
  const children = node.children
    .map((child) => {
      const next = { ...child, style: { ...child.style } };
      if (c?.kind === "switch" && child.key === "thumb" && activated)
        next.style.left = value ? width - Number(child.style.width) - 3 : 3;
      if ((c?.kind === "slider" || c?.kind === "progress") && activated) {
        if (child.key === "fill")
          next.style.width = Math.max(0, width * fraction);
        if (child.key === "thumb")
          next.style.left = Math.min(
            width - 28,
            Math.max(0, width * fraction - 14),
          );
        if (child.key === "value") next.text = `${value}%`;
      }
      if (c?.kind === "stepper" && child.key === "value")
        next.text = String(value);
      if (c?.kind === "segmented" && activated) {
        const count = c.options?.length ?? 1,
          segment = (width - 8) / count;
        if (child.key === "active")
          next.style.left = 4 + Number(value) * segment;
        if (child.key?.startsWith("label-")) {
          const selected = Number(child.key.slice(6)) === Number(value);
          next.style.fontWeight = selected ? 600 : 400;
          next.style.color = selected ? node.style.color : undefined;
        }
      }
      return next;
    })
    .filter(
      (child) =>
        !(
          c?.kind === "textfield" &&
          child.key === "value" &&
          !showPlaceholder
        ) && !(c?.kind === "checkbox" && child.key === "check"),
    );
  const visual =
    node.slotContent !== undefined ? (
      node.slotContent
    ) : (
      <>
        {node.image && <ImagePaint paint={node.image} overlay={overlay} />}
        <Vector node={node} />
        {text && (
          <span>
            {node.parts && text === node.text
              ? node.parts.map((part, i) => (
                  <span key={i} style={part.style}>
                    {part.text}
                  </span>
                ))
              : text}
          </span>
        )}
        {children.map((child) => (
          <DesignNodeView node={child} key={child.id} onAction={onAction} />
        ))}
        {c?.kind === "checkbox" && Boolean(value) && (
          <svg
            aria-hidden="true"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            style={{ position: "absolute", left: 4, top: 4, color: "#ffffff" }}
          >
            <path
              d="M5 12 L10 17 L20 6"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </>
    );
  const common = { disabled: c?.disabled, "aria-label": c?.label };
  const field = node.children.find((n) => n.key === "value");
  return (
    <div
      ref={layout.ref}
      data-design-id={node.id}
      data-forma-hotspot={
        wired || (c && !c.disabled && c.kind !== "progress") ? "" : undefined
      }
      data-forma-hover={wired && event === "hover" ? "" : undefined}
      data-component={node.name}
      style={hotspot ? { ...style, cursor: "pointer" } : style}
      {...(hotspot
        ? {
            role: "button",
            tabIndex: 0,
            "aria-label": node.name,
            onClick: (e: React.MouseEvent<HTMLDivElement>) => {
              if (
                (e.target as Element).closest("button,input,[role=button]") !==
                e.currentTarget
              )
                return;
              e.stopPropagation();
              onAction?.(node.id, true);
            },
            onKeyDown: (e: React.KeyboardEvent<HTMLDivElement>) => {
              if (
                e.target === e.currentTarget &&
                (e.key === "Enter" || e.key === " ")
              ) {
                e.preventDefault();
                e.stopPropagation();
                onAction?.(node.id, true);
              }
            },
          }
        : {})}
    >
      {c ? (
        <div aria-hidden="true" style={{ display: "contents" }}>
          {visual}
        </div>
      ) : (
        visual
      )}
      {c?.kind === "button" && (
        <button
          {...common}
          type="button"
          style={hitArea}
          onClick={() => change(true)}
        />
      )}
      {(c?.kind === "switch" || c?.kind === "checkbox") && (
        <button
          {...common}
          type="button"
          role={c.kind}
          aria-checked={Boolean(value)}
          style={hitArea}
          onClick={() => change(!value)}
        />
      )}
      {c?.kind === "textfield" && (
        <input
          {...common}
          value={String(value)}
          data-design-id={showPlaceholder ? undefined : field?.id}
          aria-placeholder={c.value === "" ? field?.text : undefined}
          onChange={(e) => change(e.target.value)}
          style={{
            ...field?.style,
            boxSizing: "border-box",
            position: "absolute",
            left: field?.style.left ?? 12,
            top: field?.style.top ?? 0,
            width: field?.style.width ?? width - 24,
            height: field?.style.height ?? height,
            padding: 0,
            border: 0,
            background: "transparent",
            color: node.style.color,
            fontFamily:
              field?.style.fontFamily ?? node.style.fontFamily ?? "inherit",
            outlineOffset: 3,
          }}
        />
      )}
      {c?.kind === "slider" && (
        <input
          {...common}
          type="range"
          min={min}
          max={max}
          step={step}
          value={Number(value)}
          onChange={(e) => change(Number(e.target.value))}
          style={{ ...hitArea, opacity: 0.01 }}
        />
      )}
      {c?.kind === "stepper" && (
        <>
          <button
            type="button"
            aria-label={`${c.label} 减少`}
            disabled={c.disabled || Number(value) <= min}
            style={{ ...hitArea, right: undefined, width: 48 }}
            onClick={() => change(Math.max(min, Number(value) - step))}
          />
          <output
            aria-live="polite"
            aria-label={`${c.label} 当前值`}
            style={{
              position: "absolute",
              width: 1,
              height: 1,
              overflow: "hidden",
              clipPath: "inset(50%)",
            }}
          >
            {String(value)}
          </output>
          <button
            type="button"
            aria-label={`${c.label} 增加`}
            disabled={c.disabled || Number(value) >= max}
            style={{ ...hitArea, left: undefined, width: 48 }}
            onClick={() => change(Math.min(max, Number(value) + step))}
          />
        </>
      )}
      {c?.kind === "segmented" && (
        <div
          role="group"
          aria-label={c.label}
          style={{ ...hitArea, display: "flex", padding: 4 }}
        >
          {c.options?.map((label, i) => (
            <button
              key={i}
              type="button"
              aria-pressed={Number(value) === i}
              aria-label={label}
              disabled={c.disabled}
              style={{
                flex: 1,
                border: 0,
                background: "transparent",
                color: "transparent",
                borderRadius: 10,
                cursor: "pointer",
              }}
              onClick={() => change(i)}
            />
          ))}
        </div>
      )}
      {c?.kind === "progress" && (
        <div
          role="progressbar"
          aria-label={c.label}
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Number(value)}
          style={{ position: "absolute", inset: 0, pointerEvents: "none" }}
        />
      )}
    </div>
  );
}

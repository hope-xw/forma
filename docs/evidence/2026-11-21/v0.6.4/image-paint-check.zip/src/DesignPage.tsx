import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { ImageResources } from "./FormaRuntime";
import images from "./design-images";

const nodes: RuntimeNode[] = [
  {
    "id": "board",
    "name": "board",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 220,
      "height": 120,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#ffffff",
      "color": "#000000",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 220,
      "height": 120
    },
    "children": [
      {
        "id": "bitmap",
        "name": "bitmap",
        "text": "",
        "type": "rectangle",
        "style": {
          "boxSizing": "border-box",
          "width": 128,
          "height": 96,
          "position": "absolute",
          "left": 8,
          "top": 8,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#000000",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "image": {
          "assetId": "img-132e59a3b08c9c87fed48f34e56352f1f3c9539222b13dfacf58caeb37693d2d",
          "fit": "tile",
          "x": 0,
          "y": 0,
          "zoom": 1.5,
          "filter": "brightness(0.5) saturate(0)",
          "tileSize": [
            16,
            8
          ]
        },
        "children": []
      },
      {
        "id": "bordered",
        "name": "bordered",
        "text": "",
        "type": "rectangle",
        "style": {
          "boxSizing": "border-box",
          "width": 128,
          "height": 14,
          "position": "absolute",
          "left": 8,
          "top": 106,
          "display": "block",
          "flexShrink": 0,
          "background": "#ffffff",
          "color": "#000000",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": "4px solid #444444",
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "image": {
          "assetId": "img-132e59a3b08c9c87fed48f34e56352f1f3c9539222b13dfacf58caeb37693d2d",
          "fit": "tile",
          "x": 0,
          "y": 0,
          "zoom": 1,
          "filter": "brightness(0.5) saturate(0)",
          "tileSize": [
            16,
            8
          ]
        },
        "children": []
      },
      {
        "id": "mask-alpha",
        "name": "mask-alpha",
        "text": "",
        "type": "group",
        "style": {
          "boxSizing": "border-box",
          "maskImage": "url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2064%2040%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3CclipPath%20id%3D%22mcrop%22%3E%3Cpath%20d%3D%22M0%200H64L64%200V40L64%2040H0L0%2040V0L0%200Z%22%2F%3E%3C%2FclipPath%3E%3C%2Fdefs%3E%3Cg%20transform%3D%22translate(32%2020)%20rotate(0)%20scale(1%201)%20translate(-32%20-20)%22%20opacity%3D%221%22%3E%3Cg%20clip-path%3D%22url(%23mcrop)%22%3E%3Cdefs%3E%3Cfilter%20id%3D%22mtilefx%22%20color-interpolation-filters%3D%22sRGB%22%3E%3CfeComponentTransfer%3E%3CfeFuncR%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3CfeFuncG%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3CfeFuncB%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3C%2FfeComponentTransfer%3E%3CfeColorMatrix%20type%3D%22saturate%22%20values%3D%220%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3Cg%20filter%3D%22url(%23mtilefx)%22%3E%3Cdefs%3E%3Cpattern%20id%3D%22mtile%22%20patternUnits%3D%22userSpaceOnUse%22%20x%3D%220%22%20y%3D%220%22%20width%3D%2216%22%20height%3D%228%22%20viewBox%3D%220%200%2016%208%22%3E%3Cimage%20width%3D%2216%22%20height%3D%228%22%20preserveAspectRatio%3D%22none%22%20href%3D%22data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAAL0lEQVR4AezQsQkAAAgDQckkjuLobqZDfPuBlIFw2ekjLZjAPZ57QAEFFFBAAQUeAAD%2F%2FwfP2SAAAAAGSURBVAMA7AMiEeWPTWUAAAAASUVORK5CYII%3D%22%2F%3E%3C%2Fpattern%3E%3C%2Fdefs%3E%3Crect%20width%3D%2264%22%20height%3D%2240%22%20fill%3D%22url(%23mtile)%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E\")",
          "maskSize": "100% 100%",
          "maskRepeat": "no-repeat",
          "maskMode": "alpha",
          "width": 64,
          "height": 40,
          "position": "absolute",
          "left": 148,
          "top": 8,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#000000",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "mask-alpha-ink",
            "name": "mask-alpha-ink",
            "text": "",
            "type": "rectangle",
            "style": {
              "boxSizing": "border-box",
              "width": 64,
              "height": 40,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "#000000",
              "color": "#000000",
              "borderRadius": 0,
              "fontSize": 16,
              "padding": 0,
              "border": 0,
              "fontFamily": "inherit",
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      },
      {
        "id": "mask-luminance",
        "name": "mask-luminance",
        "text": "",
        "type": "group",
        "style": {
          "boxSizing": "border-box",
          "maskImage": "url(\"data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2064%2040%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3CclipPath%20id%3D%22mcrop%22%3E%3Cpath%20d%3D%22M0%200H64L64%200V40L64%2040H0L0%2040V0L0%200Z%22%2F%3E%3C%2FclipPath%3E%3C%2Fdefs%3E%3Cg%20transform%3D%22translate(32%2020)%20rotate(0)%20scale(1%201)%20translate(-32%20-20)%22%20opacity%3D%221%22%3E%3Cg%20clip-path%3D%22url(%23mcrop)%22%3E%3Cdefs%3E%3Cfilter%20id%3D%22mtilefx%22%20color-interpolation-filters%3D%22sRGB%22%3E%3CfeComponentTransfer%3E%3CfeFuncR%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3CfeFuncG%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3CfeFuncB%20type%3D%22linear%22%20slope%3D%220.5%22%20intercept%3D%220%22%2F%3E%3C%2FfeComponentTransfer%3E%3CfeColorMatrix%20type%3D%22saturate%22%20values%3D%220%22%2F%3E%3C%2Ffilter%3E%3C%2Fdefs%3E%3Cg%20filter%3D%22url(%23mtilefx)%22%3E%3Cdefs%3E%3Cpattern%20id%3D%22mtile%22%20patternUnits%3D%22userSpaceOnUse%22%20x%3D%220%22%20y%3D%220%22%20width%3D%2216%22%20height%3D%228%22%20viewBox%3D%220%200%2016%208%22%3E%3Cimage%20width%3D%2216%22%20height%3D%228%22%20preserveAspectRatio%3D%22none%22%20href%3D%22data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAACAAAAAQCAYAAAB3AH1ZAAAAL0lEQVR4AezQsQkAAAgDQckkjuLobqZDfPuBlIFw2ekjLZjAPZ57QAEFFFBAAQUeAAD%2F%2FwfP2SAAAAAGSURBVAMA7AMiEeWPTWUAAAAASUVORK5CYII%3D%22%2F%3E%3C%2Fpattern%3E%3C%2Fdefs%3E%3Crect%20width%3D%2264%22%20height%3D%2240%22%20fill%3D%22url(%23mtile)%22%2F%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E\")",
          "maskSize": "100% 100%",
          "maskRepeat": "no-repeat",
          "maskMode": "luminance",
          "width": 64,
          "height": 40,
          "position": "absolute",
          "left": 148,
          "top": 64,
          "display": "block",
          "flexShrink": 0,
          "background": "transparent",
          "color": "#000000",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "mask-luminance-ink",
            "name": "mask-luminance-ink",
            "text": "",
            "type": "rectangle",
            "style": {
              "boxSizing": "border-box",
              "width": 64,
              "height": 40,
              "position": "absolute",
              "left": 0,
              "top": 0,
              "display": "block",
              "flexShrink": 0,
              "background": "#000000",
              "color": "#000000",
              "borderRadius": 0,
              "fontSize": 16,
              "padding": 0,
              "border": 0,
              "fontFamily": "inherit",
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":390,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;

export default function DesignPage({ onAction }: { onAction?: DesignAction }) {
  return <ImageResources.Provider value={images}><main style={pageStyle}>{nodes.map(node => <DesignNodeView key={node.id} node={node} onAction={onAction}/>)}</main></ImageResources.Provider>;
}

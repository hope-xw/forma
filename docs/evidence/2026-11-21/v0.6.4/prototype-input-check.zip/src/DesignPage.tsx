import type { CSSProperties } from "react";
import { DesignNodeView, type RuntimeNode, type DesignAction } from "./FormaRuntime";
import { ProjectPrototypePlayer as PrototypePlayer } from "./PrototypePlayer";
import type { Program } from "./prototype-machine";

const nodes: RuntimeNode[] = [
  {
    "id": "Home",
    "name": "Home",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 320,
      "height": 200,
      "position": "absolute",
      "left": 0,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#f1f2f6",
      "color": "#111111",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 320,
      "height": 200
    },
    "children": [
      {
        "id": "HoverCard",
        "name": "HoverCard",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 240,
          "height": 80,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "block",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": [
          {
            "id": "Details",
            "name": "Details",
            "text": "Details",
            "type": "button",
            "style": {
              "boxSizing": "border-box",
              "width": 140,
              "height": 44,
              "position": "absolute",
              "left": 16,
              "top": 12,
              "display": "flex",
              "justifyContent": "center",
              "alignItems": "center",
              "flexShrink": 0,
              "background": "#f1f2f6",
              "color": "#111111",
              "borderRadius": 0,
              "fontSize": 16,
              "padding": 8,
              "border": 0,
              "fontFamily": "inherit",
              "whiteSpace": "pre-wrap",
              "overflowWrap": "break-word",
              "margin": 0
            },
            "children": []
          }
        ]
      },
      {
        "id": "Counter",
        "name": "Counter",
        "text": "",
        "type": "frame",
        "style": {
          "boxSizing": "border-box",
          "width": 160,
          "height": 44,
          "position": "absolute",
          "left": 16,
          "top": 100,
          "display": "block",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 0,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "geometry": {
          "width": 160,
          "height": 44
        },
        "control": {
          "kind": "stepper",
          "label": "件数",
          "value": 0,
          "min": 0,
          "max": 3,
          "step": 1
        },
        "children": []
      }
    ]
  },
  {
    "id": "Detail",
    "name": "Detail",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 320,
      "height": 200,
      "position": "absolute",
      "left": 360,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#f1f2f6",
      "color": "#111111",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 320,
      "height": 200
    },
    "children": [
      {
        "id": "GoBack",
        "name": "GoBack",
        "text": "Back",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 100,
          "height": 44,
          "position": "absolute",
          "left": 12,
          "top": 16,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  {
    "id": "Sheet",
    "name": "Sheet",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 240,
      "height": 120,
      "position": "absolute",
      "left": 730,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#f1f2f6",
      "color": "#111111",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 240,
      "height": 120
    },
    "children": [
      {
        "id": "More",
        "name": "More",
        "text": "More",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 100,
          "height": 44,
          "position": "absolute",
          "left": 12,
          "top": 12,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  {
    "id": "Inner",
    "name": "Inner",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 200,
      "height": 80,
      "position": "absolute",
      "left": 1010,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#f1f2f6",
      "color": "#111111",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 200,
      "height": 80
    },
    "children": [
      {
        "id": "Done",
        "name": "Done",
        "text": "Done",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 100,
          "height": 44,
          "position": "absolute",
          "left": 12,
          "top": 12,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  },
  {
    "id": "HoverSheet",
    "name": "HoverSheet",
    "text": "",
    "type": "frame",
    "style": {
      "boxSizing": "border-box",
      "width": 200,
      "height": 100,
      "position": "absolute",
      "left": 1250,
      "top": 0,
      "display": "block",
      "flexShrink": 0,
      "background": "#f1f2f6",
      "color": "#111111",
      "borderRadius": 0,
      "fontSize": 16,
      "padding": 0,
      "border": 0,
      "fontFamily": "inherit",
      "whiteSpace": "pre-wrap",
      "overflowWrap": "break-word",
      "margin": 0
    },
    "geometry": {
      "width": 200,
      "height": 100
    },
    "children": [
      {
        "id": "Hide",
        "name": "Hide",
        "text": "Hide",
        "type": "button",
        "style": {
          "boxSizing": "border-box",
          "width": 120,
          "height": 44,
          "position": "absolute",
          "left": 0,
          "top": 0,
          "display": "flex",
          "justifyContent": "center",
          "alignItems": "center",
          "flexShrink": 0,
          "background": "#f1f2f6",
          "color": "#111111",
          "borderRadius": 0,
          "fontSize": 16,
          "padding": 8,
          "border": 0,
          "fontFamily": "inherit",
          "whiteSpace": "pre-wrap",
          "overflowWrap": "break-word",
          "margin": 0
        },
        "children": []
      }
    ]
  }
];
const pageStyle = {"position":"relative","minWidth":1450,"minHeight":800,"fontFamily":"system-ui, sans-serif"} as CSSProperties;
const program: Program = {
  "flows": [
    {
      "id": "Home",
      "name": "Main"
    }
  ],
  "rules": {
    "HoverCard": {
      "trigger": "hover",
      "actions": [
        {
          "kind": "overlay",
          "target": "HoverSheet",
          "position": "center"
        }
      ]
    },
    "Details": {
      "actions": [
        {
          "kind": "navigate",
          "target": "Detail"
        }
      ]
    },
    "Counter": {
      "actions": [
        {
          "kind": "overlay",
          "target": "Sheet",
          "position": "center"
        }
      ]
    },
    "GoBack": {
      "actions": [
        {
          "kind": "back"
        }
      ]
    },
    "More": {
      "actions": [
        {
          "kind": "overlay",
          "target": "Inner",
          "position": "center"
        }
      ]
    },
    "Done": {
      "actions": [
        {
          "kind": "close"
        }
      ]
    },
    "Hide": {
      "actions": [
        {
          "kind": "close"
        }
      ]
    }
  },
  "variables": {},
  "cssNames": {}
};
export const flows = program.flows;

export default function DesignPage({ flow = flows[0].id, onAction }: { flow?: string; onAction?: DesignAction }) {
  return <PrototypePlayer key={flow} nodes={nodes} program={program} start={flows.some(f => f.id === flow) ? flow : flows[0].id} onAction={onAction} style={pageStyle}/>;
}
